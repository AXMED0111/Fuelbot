# FuelBot PRO — Exchange Proxy

Handles CORS + HMAC-SHA256 request signing for Binance, OKX and MEXC spot orders.
Your API secrets never touch the browser — they are sent to this proxy, which signs
the request and forwards it to the exchange.

---

## Your Railway Setup (already created)

| Item | Value |
|---|---|
| Project | `fuelbot-proxy` |
| Service | `fuelbot-api` |
| URL | `https://fuelbot-api-production.up.railway.app` |
| Bot Secret | `fuelbot_YWWWYshh4jH4wL8ZWcR5BKa9Szti` |

Environment variables `BOT_SECRET`, `FRONTEND_URL` and `NODE_ENV` are already set.
The service just needs its code — follow either method below.

---

## Deploy — Method A: GitHub (recommended)

Auto-redeploys every time you push.

1. Create a new repo at https://github.com/new — name it `fuelbot-proxy`, keep it **private**
2. Upload these 5 files (drag and drop works):
   - `server.js`
   - `package.json`
   - `railway.json`
   - `.gitignore`
   - `README.md`
3. Open https://railway.app → project **fuelbot-proxy** → service **fuelbot-api**
4. Settings → Source → **Connect Repo** → pick `fuelbot-proxy` → branch `main`
5. Railway builds and deploys automatically (~60 seconds)

Or from a terminal:

```bash
cd fuelbot-proxy
git init
git add .
git commit -m "FuelBot proxy"
git branch -M main
git remote add origin https://github.com/YOUR_USERNAME/fuelbot-proxy.git
git push -u origin main
```

---

## Deploy — Method B: Railway CLI

No GitHub needed.

```bash
npm i -g @railway/cli
railway login
cd fuelbot-proxy
railway link --project af362055-fd32-4979-a6f5-4dc4cf331e48
railway up --service fuelbot-api
```

---

## Verify It Works

Open in a browser:

```
https://fuelbot-api-production.up.railway.app/health
```

Expected response:

```json
{ "ok": true }
```

Then open the root URL to see which exchanges are wired:

```
https://fuelbot-api-production.up.railway.app/
```

```json
{
  "status": "ok",
  "service": "FuelBot PRO v4 Proxy",
  "exchanges": ["binance", "okx", "mexc"]
}
```

---

## Connect the Bot

The proxy URL and secret are **already pre-filled** in `fuelbot-pro-v5.html`.

1. Open the bot, enter password `4043585`
2. Go to ⚙ Settings → scroll to **Proxy**
3. Press **Test Proxy** — should show ✅ green
4. Add your exchange API keys in the Exchange tab
5. Toggle the exchange ON

---

## API Routes

| Route | Method | Purpose |
|---|---|---|
| `/` | GET | Service info + exchange list |
| `/health` | GET | Health check (used by Railway) |
| `/binance/order` | POST | Place spot order |
| `/binance/balance` | POST | Read account balance |
| `/binance/cancel` | POST | Cancel open order |
| `/okx/order` | POST | Place spot order |
| `/okx/balance` | POST | Read account balance |
| `/mexc/order` | POST | Place spot order |
| `/mexc/balance` | POST | Read account balance |
| `/ai/analyse` | POST | Claude market analysis |

All POST routes require the header `X-Bot-Secret`. Requests without it get `401`.

---

## Environment Variables

| Variable | Required | Notes |
|---|---|---|
| `BOT_SECRET` | Yes | Already set. Must match the bot's Settings value. |
| `FRONTEND_URL` | Yes | Already set to `*`. Lock to your domain later. |
| `NODE_ENV` | No | Already set to `production` |
| `ANTHROPIC_KEY` | Optional | Only needed for the AI Analysis feature |
| `PORT` | No | Railway sets this automatically |

To add the Anthropic key: Railway → fuelbot-api → Variables → New Variable.

---

## Adding More Exchanges Later

Each exchange is a self-contained block in `server.js`. To add one (Bybit, KuCoin, Gate.io):

1. Copy the `/mexc/order` block as a template
2. Change the base URL and the signature format
3. Add the route name to the `exchanges` array in the `/` handler
4. Push — Railway redeploys automatically

The bot already has `sendToExchange()` wired to route by exchange name, so adding
the route on the proxy is usually all that is needed.

---

## Security Notes

- API secrets are sent per-request and never written to disk or logged
- `BOT_SECRET` blocks anyone else from using your proxy
- Set `FRONTEND_URL` to your actual domain once you deploy the bot publicly
- On the exchange side, enable **Spot Trading only** — never enable withdrawals
- Whitelisting Railway's egress IP is supported by Binance and MEXC; OKX requires it
